import numpy as np
from abc import ABC, abstractmethod
from typing import Union, Tuple, List, Dict

from dataclasses import dataclass
import torch
from neuralop.layers.fno_block import FNOBlocks

from fnofound.data.data.transforms.base_transforms import Transform
from fnofound.data.data.transforms.data_processors import DefaultDataProcessor

@dataclass
class Message:
    '''
    Message of fixed type to send between agents: 
    Format as "I am agent ``id'': to followup agents ``followup_ids'': check your readiness"
    '''    
    id: int
    followup_ids: List[int] # or change to List[Tuple[int, bool]] as 

@dataclass
class CalcMessage(Message):
    '''
    Message of fixed type to send between agents: 
    approved format as "I am agent ``id'': to followup agents ``followup_ids'': 
                        check your readiness, if everything ready - commence.
                        Calculated channel ``C'' on horizon ``[(t_0, t_1), (x1_0, x1_1), ...]''."
    '''
    channel  : int
    horizon  : List[Tuple[int]]

@dataclass
class ChannelExtensionMessage(Message):
    '''
    Message of fixed type to send between agents: 
    approved format as "I am agent ``id'': to followup agents ``followup_ids'': 
                        check your readiness, if everything ready - commence.
                        I have added channel/channels N/N to M."
    '''
    channels: Union[int, Tuple[int]]

    # executed : bool = True

    # def __init__(self, calculated_channel: int, horizon: List[Tuple[int]]):
    #     self.calculated_channel = calculated_channel


class EnvMeta(type):
    _env_instances = {}
    
    def __call__(cls, *args, **kwargs): 
        if cls not in cls._env_instances:
            instance = super().__call__(*args, **kwargs)
            cls._env_instances[cls] = instance
            
        return cls._env_instances[cls]
    
    def reset(self):
        self._env_instances = {}


class NeuralOpSystemEnvironment(metaclass = EnvMeta):
    def __init__(self):
        pass
    
    def setTensor(self, initial_tensor: torch.Tensor, channel_meta: List[int]):
        '''
        Object for an environment for neuralop-based agents. Exists as a large torch.Tensor, 
        where initial conditions are gradually replaced with predictions.

        Args:
            initial_tensor: torch.Tensor, 
                Tensor of inputs (initial conditions & external channels, e.g. forcings, grids, etc.)
            channel_meta: List[int],
                Numbers of variables, set with the IC in channels. From 0 and up. -1 marks external channel.

        '''
        assert len(channel_meta) == initial_tensor.shape[1], 'Mismatching channels and descriptions.'

        self._env = initial_tensor
        self._env_shape = initial_tensor.shape
        self._channel_meta = channel_meta

    def access(self, channels: List[Union[Tuple[int], List[int], int]]) -> torch.Tensor: # Send slices as tuples of ints
        chan_indexes = []
        for elem in channels:
            if isinstance(elem, int):
                chan_indexes.append(elem)
            elif isinstance(elem, tuple):
                chan_indexes += list(elem)
            elif isinstance(elem, list):
                chan_indexes += elem
            else:
                raise NotImplementedError('Got incorrect index, expected int, or list/tuple of ints.')

        return self._env[:, tuple(chan_indexes), ...]

    def modifyChannels(self, channels: List[Union[Tuple[int], List[int], int]], inp: torch.Tensor) -> None:
        # Add check of inp shape
        if isinstance(channels, int):
            # inp shape has to be [B, 1, T, ...]
            self._env[:, channels, ...] = inp
        else:
            for inner_chan_idx, channel in enumerate(channels):
                self._env[..., channel, ...] = inp[:, inner_chan_idx, ...]

    def concatNewChannels(self, new_channels: torch.Tensor) -> None:
        '''
        Function to add new channels, may be set not by batch (e.g. as [C x T x X x ...])
        '''
        if new_channels.shape[0] == 1 or new_channels.ndim < self._env.ndim:
            # Maybe add asserts

            self._channel_meta += [-1,] * new_channels.shape[0]

            repeat_shape = [1 for _ in self._env.shape]
            repeat_shape[0] =  self._env.shape[0]

            self._env = torch.concat([self._env, 
                                      torch.unsqueeze(new_channels, 0).repeat(repeat_shape)], dim = 1)
        else:
            self._channel_meta += [-1,] * new_channels.shape[1]
            self._env = torch.concat([self._env, new_channels], dim = 1)

    def getVarState(self) -> torch.Tensor:
        indexes = tuple([i for i in range(self._env.shape[1]) if self._channel_meta[i] != -1])
        return self._env[:, indexes, ...]

    # def addParametricChannels(self):

def checkShapeMatching(inp: torch.Tensor, other_tensors: List[torch.Tensor]) -> bool:
    if len(other_tensors) == 0:
        return True
    else:
        if inp.ndim != other_tensors[0].ndim:
            return False
        for idx in range(inp.ndim):
            if idx == 1:
                continue # Here we assert, that inputs may have different number of channels
            if inp.shape[idx] != other_tensors.shape[idx]:
                return False

        return True        


class AbstractAgent(ABC):
    def __init__(self):
        pass

    @abstractmethod
    def passMessage(self):
        raise NotImplementedError('Trying to call passMessage of an abstract agent.')


class BasicAgent(AbstractAgent):
    def __init__(self, id: int,
                 env: NeuralOpSystemEnvironment,
                 predecessors : List[Tuple[int, AbstractAgent]],
                 successors   : List[Tuple[int, AbstractAgent]] = None):
        self._id = id

        self.env = env
        self._predecessors = predecessors

        if successors is None:
            self._successors = {}
        else:
            self._successors = successors

        self._predecessors_exec = {id: False for id, _ in self._predecessors}

    def checkReadiness(self) -> bool:
        return all(self._predecessors_exec.values())
    
    def resetReadiness(self) -> None:
        for key in self._predecessors_exec.keys():
            self._predecessors_exec[key] = False

    def resetSuccessors(self) -> None:
        self._successors = {}

    def addSuccessor(self, successor: Tuple[int, AbstractAgent]) -> None:
        if successor[0] in self._successors.keys():
            raise RuntimeError('ID of successor already in the operator')
        self._successors[successor[0]] = successor[1]            

class ICLoaderMeta(type):
    _ic_loaders_instances = {}
    
    def __call__(cls, *args, **kwargs): 
        if cls not in cls._ic_loaders_instances:
            instance = super().__call__(*args, **kwargs)
            cls._ic_loaders_instances[cls] = instance
            
        return cls._ic_loaders_instances[cls]
    
    def reset(self):
        self._ic_loaders_instances = {}

class InitialConditionsAgent(metaclass = ICLoaderMeta):
    _id = 0
    
    def __init__(self, 
                 env: NeuralOpSystemEnvironment,
                 initial_conds: Dict[int, torch.Tensor],
                 additional_channels: torch.Tensor,
                 predecessors: Dict[int, AbstractAgent] = None):
        '''

        Args:
            inputs (Dict[int, torch.Tensor]): dict of tensors of initial conditions [B, C*, 1, X, Y, ...]
                keys - IDs of the required operators
            additional_channels (torch.Tensor) : torch Tensor of additional pre-defined channels (e.g. forcings)
                [B, C_add, T, X, Y, ...]

        C* - number of channels per variable in specific IC tensor. Typically, 1. 
        '''
        self.env = env

        self._additional_channels = additional_channels
        self._initial_conds = initial_conds
        
        self._predecessors = predecessors
        # self._from_predecessors = {}
        self.resetSuccessors()

    def resetSuccessors(self) -> None:
        self._successors = {}

    def addSuccessor(self, successor: Tuple[int, AbstractAgent]) -> None:
        if successor[0] in self._successors.keys():
            raise RuntimeError('ID of successor already in the operator')
        self._successors[successor[0]] = successor[1]

    def formInputTensor(self, id: int,
                        from_predecessors: Union[Dict[int, torch.Tensor], 
                                                 List[torch.Tensor]] = None) -> Dict[int, torch.Tensor]:
        # Maybe add better memory usage
        tensors = []
        for id, tensor in self._initial_conds.items():
            tensors.append(tensor)

        tensors.append(self._additional_channels)

        return torch.cat(tensors, dim = 1)

    def passMessage(self, inc_message: Message = None) -> bool:
        # Let's assume, that the inc. message is None, i.e. this is the "first executed agent"
        
        self.env.setTensor(self.formInputTensor(self._initial_conds), 
                           [ID for ID in self._initial_conds.keys()])

        for scs_id, scs_agent in self._successors:
            exec_flag = scs_agent.passMessage()
    

    # def passMessage(self) -> bool:
    #     other_tensors = {}

        

    #     for scs_id, scs_agent in self._successors:
    #         exec_flag, multiagent_tensors = scs_agent.passMessage(x)
    #         if not exec_flag:
    #             other_tensors[scs_id] = multiagent_tensors

    #     return True, other_tensors

class NeuralOperatorAgent(BasicAgent):
    def __init__(self,
                 id: int,
                 env: NeuralOpSystemEnvironment,
                 adapters      : Tuple[torch.nn.Module, Tuple[torch.nn.Module]],
                 core          : Union[FNOBlocks, torch.nn.Module],
                 predecessors  : List[Tuple[int, AbstractAgent]],
                 successors    : List[Tuple[int, AbstractAgent]] = None,
                 preprocessors : Union[Tuple[Transform], DefaultDataProcessor] = None,
                 channel_ord   : List[int] = None, # ordered ids of channels
                 device        : str = 'cuda'
                 ):
        super().__init__(id, env, predecessors, successors)

        self._preprocessors = preprocessors
        self._adapters = adapters
        self._core = core
        # self._previous_pred = None
        self._channel_ord = channel_ord
        
        self._device = device

    # def addOpInput(self, predecessor_id: int, inp: torch.Tensor) -> None:
    #     if predecessor_id in self._neuralop_inputs.keys():
    #         raise ValueError(f'Conflicting IDs of operator inputs: {predecessor_id} already in {self._neuralop_inputs.keys()}')
    #     self._neuralop_inputs[predecessor_id] = inp

    # def formInput(self) -> torch.Tensor:
    #     tensors_to_concat = [None for _ in self._neuralop_inputs.keys()]
        
    #     for tensor_id, tensor in self._neuralop_inputs.items():
    #         checkShapeMatching(tensor, tensors_to_concat)
    #         tensors_to_concat[self._channel_ord.index(tensor_id)] = tensor
        
    #     return torch.concat(tensors_to_concat, dim = 1)

    def formInput(self) -> torch.Tensor:
        return self.matchDevice(self.env.access(self._channel_ord))
 
    # def resetNeuralOpInputs(self) -> None:
    #     self._neuralop_inputs = {} # Dict of torch tensors: key - int, must match index of channel

    # def checkNeuralOpInputs(self) -> bool:
    #     # TODO: possibly add extra connections and checks
    #     correct_inputs = [(len(self._neuralop_inputs) == len(self._predecessors)),]

    #     return all(correct_inputs)

    def matchDevice(self, arg: torch.Tensor):
        if not arg.device == self._device:
            arg.to(self._device)

        return arg

    def setPreprocessors(self):
        pass

    def coreCall(self, lifted_x: torch.Tensor) -> torch.Tensor:
        # TODO: necessary asserts
        return self._core(lifted_x)

    @property
    def adapters(self) -> Tuple[torch.nn.Module]:
        # TODO: necessary asserts
        return self._adapters
    
    @adapters.setter
    def adapters(self, passed_adapters: Tuple[torch.nn.Module, Tuple[torch.nn.Module]]) -> None:
        # TODO: necessary asserts
        assert len(passed_adapters) == 2, 'arguments of the adapters setter have to include both lifting and projection'
        self._adapters = passed_adapters

    def __call__(self, x: torch.Tensor) -> torch.Tensor:
        # TODO: add necessary asserts about tensors

        if self._preprocessors is not None:
            if isinstance(self._preprocessors, tuple):
                x = self._preprocessors[0].transform(x)
            else:
                raise NotImplementedError('DefaultDataProcessor is too inconvenient, use Transform subclasses')

        x = self.adapters[0](x)
        x = self.coreCall(x)
        x = self.adapters[1](x)

        if self._preprocessors is not None:
            if isinstance(self._preprocessors, tuple):
                x = self._preprocessors[1].inverse_transform(x)
            else:
                raise NotImplementedError('DefaultDataProcessor is too inconvenient, use Transform subclasses')        

        return x

    def passMessage(self, message: Message, *args, **kwargs) -> bool:
        # Tuple[bool, Dict[int, torch.Tensor]]: # Or just bool as a flag of correct execution?
        # pred_id: int, # inp: Union[torch.Tensor, Dict[int, torch.Tensor], List[torch.Tensor]],

        self.addOpInput(message.id)

        if not self.checkReadiness():
            return False, []

        if not self.checkNeuralOpInputs():
            raise RuntimeError("Incorrect inputs, mismatching requirements of the operator")

        x = self(self.formInput())
        # self._previous_pred = x

        other_tensors = {self._id : x}
        for scs_id, scs_agent in self._successors:
            exec_flag, multiagent_tensors = scs_agent.passMessage(x)
            if not exec_flag:
                other_tensors[scs_id] = multiagent_tensors

        return True, other_tensors

class DataPatchingAgent(BasicAgent):
    def __init__(self, axis: int, window_size: int):
        self._axis = axis
        self._window_size = window_size

        self.reset()

    def reset(self) -> None:
        self._cur_pos = 0

    def __call__(self, arg: torch.Tensor) -> torch.Tensor:
         # Maybe use torch split instead and then feed other agents
        arg = torch.narrow(arg, self._axis, self._cur_pos, self._window_size)
        self._cur_pos += self._window_size
        return arg


class FixedMultiAgentSystem(object):
    '''
    In current iteration, the MAS will be just a pre-defined set of agents with fixed roles and inter-agent links.
    '''
    ID_low  = 1 
    ID_high = 1e2 # Probably, there will be no need in more than 100 agents

    def __init__(self):
        self._unused_ids = np.arange(self.ID_low, self.ID_high)
        self._agents = {}
        self._initial_agent_id = None
        # agents shall be in form ID "int" : (agent "subclass of BasicAgent", list of outgoing agents "list of ID ints")

    def addAgent(self, agent: BasicAgent, outgoings: List[int] = None) -> None:
        if outgoings is None:
            outgoings = []

        valid_ids = self._unused_ids[~np.isin(self._unused_ids, list(self._agents.keys()))]
        id = np.random.choice(valid_ids)
        self._agents[id] = (agent, outgoings)
        
    def linkAgent(self, id_from: int, id_to: int):
        assert isinstance(self._agents[id_from][1], list), 'Second position of agent in dict must be a list' 
        self._agents[id_from][1].append(id_to)

    # def __call__(self, arg: torch.Tensor, *args, **kwds):
    #     while 

if __name__ == "__main__":
    env = NeuralOpSystemEnvironment()

    tensor_1 = torch.rand(size=(10, 1, 12, 32, 32))
    tensor_2 = torch.rand(size=(10, 2, 12, 32, 32))
    tensor_3 = torch.rand(size=(10, 1, 12, 32, 32))

    initial_cond_loader = InitialConditionsAgent(env = env,
                                                 initial_conds = {'1': tensor_1,
                                                                  '2': tensor_2,
                                                                  '3': tensor_3},
                                                 additional_channels = torch.rand(size=(10, 3, 12, 32, 32)), 
                                                 )
    
    adapters = ()
    core = None

    pressure_agent = NeuralOperatorAgent(id = 0, 
                                         env = env,
                                         adapters = adapters,
                                         core = core)
    